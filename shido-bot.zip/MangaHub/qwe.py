string = r"\t\t\t\n\t\t\thttps://my.1stkmgv1.com/manga_5d8d9f6d63110/chapter-0/1.jpg"

a = string.index("https://")
print(a)
print(string[string.index("https://"):])
